class TokenIsNotValid(Exception):
    pass


class KafkaMessageError(Exception):
    pass
